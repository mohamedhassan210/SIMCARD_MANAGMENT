using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SimUsbManagement.Models
{
    public class Subscription
    {
        [Key]
        public int Id { get; set; }

        public int? EmpId { get; set; }          // nullable if assigned to NonEmployee

        public int? NonEmployeeId { get; set; }  // nullable if assigned to Employee

        [Required]
        public int SimId { get; set; }

        public int? UsbId { get; set; }

        [Required]
        public int QuotaId { get; set; }

        [Required]
        public int ActionId { get; set; }

        [Required]
        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        [Required]
        public DateTime StartDate { get; set; }

        public DateTime? EndDate { get; set; }  // null = open ended

        [StringLength(500)]
        public string? Notes { get; set; }

        // Navigation properties
        [ForeignKey(nameof(EmpId))]
        public virtual Employee? Employee { get; set; }

        [ForeignKey(nameof(NonEmployeeId))]
        public virtual NonEmployee? NonEmployee { get; set; }

        [ForeignKey(nameof(SimId))]
        public virtual Sim Sim { get; set; } = null!;

        [ForeignKey(nameof(UsbId))]
        public virtual Usb? Usb { get; set; }

        [ForeignKey(nameof(QuotaId))]
        public virtual Quota Quota { get; set; } = null!;

        [ForeignKey(nameof(ActionId))]
        public virtual DeviceAction Action { get; set; } = null!;

        [ForeignKey(nameof(CreatedBy))]
        public virtual User CreatedByUser { get; set; } = null!;

        public virtual ReceiverSignature? ReceiverSignature { get; set; }
        public virtual ICollection<DeviceTransfer> DeviceTransfers { get; set; } = new List<DeviceTransfer>();
    }
}
